# Reply 20 — you found a contradiction I wrote against myself, and it is the last one

Both answers below. And because the author's question was really *"is this design finished
enough to build against"*, there is an audit at the end rather than an apology.

---

## ★ 1. T1 takes the family in the text. Option 1, with a derived colour.

You are right, and the framing is exact: **a house-fixed T1 is a contradiction in terms.** I wrote
*"T1 means the top of this category — a claim about the family, so it renders in the family's own
vocabulary"*, and then left a recipe rendering it in the one palette defined as not the family's.
Gear hid it because gear's hue is a neutral grey. Uniques is where it is legible, and brown-red-
brown-brown is the tell.

**T1 keeps the house red plate and takes the family in the text.**

That is not a new construction — it is exactly what **T0 already does**: house plate, family text.
So T0 and T1 stop being one family-aware rung and one that is not, and become one idea:

> **The plate carries the rank. The text carries the family. Both house rungs, same sentence.**

**The colour is derived, not authored:** `accent.solid` lightened until it clears **3:1** on
`210 0 0` — the same threshold T0 already uses on white, and the right one because T1 is 45px.
4.5:1 would push every accent to within a hair of white and undo the point. For uniques that lands
around `240 190 145`.

### Why not the other two

**Option 2 — invert T2, red on the border — is unavailable**, and this is the one worth stating
because it looks like the elegant answer. **Uniques carry three states** (corrupted, linked,
influenced), so the border is not idle there; it is one of the busiest in the filter. The
border-is-reserved constraint is a one-pass build constraint with no exceptions, and spending it on
the category with the most states to compose is the worst place to start.

**Option 3 — leave it — costs more than it saves.** The rule is load-bearing: it is what keeps
Campaign T1 on its dark plate. An exception reading *"except on painted accents, where T1 is
house-fixed after all"* would cover every painted category in the filter. That is not an exception,
it is a repeal.

⚠️ **Scope, stated plainly: this touches every painted T1, not just uniques.** It should look like
a systematic change because it is one. If you would rather see it in game before committing, **ship
uniques alone first** — the derivation is per-accent, so a partial rollout is coherent rather than
half-applied. Your call; I would not consider it a compromise either way.

**One interaction I checked before writing it:** this does *not* weaken
`_swaps_never_paint_the_house_rungs`. That rule forbids a **swap** over a house plate, because a
swap is a claim about the instance and the house plate already makes the loudest claim available.
Family identity is not a claim about the instance — it is which category the item is in. The two
never contend, because no swap fires at T0 or T1 by that same rule.

## 2. Merge them. The two tiers should not both exist.

My *"nine tiers into six rungs means rungs carry two"* defence applies to tiers adjacent in **rank**.
These two are adjacent in **meaning** — *"ordinary unique"* and *"every other unique"* is a
distinction with nothing behind it once they render identically, and two tiers paying for one idea
is the cost without the benefit.

`Uniques/General.json` becomes **(4) `T0 T1 T2 T3`**. At depth 4 the value template gives exactly
that, so the override is now redundant; I have kept it only because Uniques' spread is the reason
it has its own accent, and I would rather that reasoning stay attached to the file.

---

## 3. The audit — because "is this deliverable?" is the real question

Six contradictions have come out of this thread, all found by you, none by me. They have one cause:
**a rule written in one place, and a recipe or note elsewhere that predates it or does not know
about it.** That is not carelessness that more care fixes — it is a missing index.

So the kit now has one: **`_rule_index`**, every general rule stated once with its scope, and
nothing counted as a rule unless it is there. The discipline that goes with it: *before writing a
new rule, check it against every entry.* This T1 fix is the first one I ran that way, which is how
I caught the swap interaction above before you did.

For the record, the six and their status:

| # | contradiction | closed by |
|---|---|---|
| 1 | `rung_by_depth` in two files, disagreeing at depth 3 | reply 14 — one owner |
| 2 | `theme-standard.md` prose vs both machine files | reply 16 — prose corrected, machine wins |
| 3 | `_note` prose vs the array beside it (×2) | reply 16 — `_note_discipline` |
| 4 | `rarity_through` invariant vs the maps exception | reply 17 — maps paint |
| 5 | swap rule "T0/T1" vs maps having no house plate | reply 18 — restated as plates |
| 6 | **T1 relative vs the house-fixed T1 recipe** | **this reply** |

**None are outstanding.** Four of the six were the same failure — a general rule and a specific
recipe written months apart in the same file — which is exactly what the index is for.

## 4. On your five map defects

The one that matters is (3), and you have it right: **52 of ~67 categories ordered by filename**
means any negative `gen_order` with a loose condition can reach across the whole tree silently. An
equipment purpose beating a map block by eighty thousand positions is not a bug you can find by
reading either block.

And it was found *because the influenced decorator drew a purple border on a Shaper Guardian Map* —
the state channel making a mismatch visible on the ground. That is the border earning its
reservation in a way I did not anticipate when I argued for it.

The `RANGE >= 6 0 10` one is the scariest of the five: the filter **loaded without complaint** and
most maps in the game matched nothing. Worth remembering next time a load comes back clean.

---

## Still mine

The icon floor sweep — Legacy at 17/17 is still the biggest single cut. Nothing else is open on the
design side.
