repo: Shiningingy/POE_filter_project
branch: feature/theme-pipeline-rewrite
path: docs/design/

Read this branch, not `main` — the theme pipeline rewrite lives here.
(`feature/3.29-tuning` was merged and deleted; the earlier branch name
`feature/them-pipeline-rewrite` was a typo and does not exist.)

## Reference repo (read-only, not ours)
NeverSinkDev/NeverSink-Filter @ `057a0763` — PoE1 filters live in the repo root at that
commit (they are NOT on `master` HEAD, which keeps only the changelog). Icon and beam
conventions on the board were measured from it by `github_search_code`, not recalled.

## Last sync
date: 2026-08-03T20:37:08Z

### Updated in this project
- Read the rewritten pipeline design (`docs/design/theme-pipeline-rewrite.md`) — the
  `theme_category × Tier N` grid is retired; a tier block owns its look, rules own matching.
- Answered workstream E (the designer's beam/icon vocabulary) as a new board.
- Working from `uploads/designer-brief-palette-c2d2d078.md` (supersedes the earlier upload),
  sent directly by the author and NOT tracked in git — its §3(c) records that `Continue`
  was tested in game and composes per-property, which the board now relies on.
- Measured NeverSink's icon/beam conventions from the reference repo above: shape = category,
  size + colour = tier, 4,602 `Temp` beams (mostly Grey).
- Read Sharket's own gear ladder (`filter_generation/data/theme/sharket/sharket_theme.json`,
  Body Armours) and rewrote workstream E's equipment section from it: border carries the rung,
  plate darkens under it and vanishes at T4, gear gets its own 45/42/39/36/34/31 size ramp,
  and four group hues replace the single `equipment` accent. See
  `handoff/reply-10-gear-ladder.md`.
- Measured NeverSink on heist: contracts and blueprints are matched together, grouped as
  "maplike" with logbooks/memories, and tiered by a handpicked list of nine AREAS rather than
  by value — and their contract block draws `MinimapIcon 0 Green Pentagon`, the largest icon
  the game has. So heist bottoms out at T3 and never reaches the bulk rungs; Pentagon comes
  out of reserve. See `handoff/reply-07-heist-maplike.md` + `reply-08-heist-correction.md`.
- Measured NeverSink on deep categories (>=4 tiers): the plate does NOT ramp per tier — one
  background per category held across ~50 consecutive blocks (`47 0 74`, `40 0 40`, `20 20 0`).
  This changed the design: T3-T5 now share one plate and rank in the text. See
  `handoff/reply-04-plate-rule.md`.
- Delivered the code-side handoff for workstream E: `handoff/theme-standard.md` (spec in the
  rewrite's own vocabulary) and `handoff/theme-presets.json` (accents + rung recipes + goldens),
  plus `accent-category-map.json` mapping all 75 theme categories, and replies 02-04.
- Moved the retired hue-arc artifacts to `handoff/_superseded/`.

## Screen map
| screen | built from |
|---|---|
| Theme Standard — Plates, Beams & Icons.dc.html | uploads/designer-brief-palette.md · data/from_designer/theme_palette_2026-07-18.txt · docs/design/theme-pipeline-rewrite.md · docs/design/visual-encoding-brief.md · docs/design/theme-coverage.md |

## Sync history
- 2026-07-31 — `feature/3.29-tuning`: 51-category hue-arc theme, since superseded.
